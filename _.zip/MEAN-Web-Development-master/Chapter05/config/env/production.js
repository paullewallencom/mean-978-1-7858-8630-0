// Set the 'production' environment configuration object
module.exports = {
	db: 'mongodb://localhost/mean-production',
	sessionSecret: 'productionSessionSecret'
};