// Define the module method
module.exports = function() {
	// Define functional variable
	const message = 'Hello';

	// Print the message variable to the console
	console.log(message);
};