// Load the 'hello' module
const hello = require('./hello');

// Call the 'hello' module as a function
hello();