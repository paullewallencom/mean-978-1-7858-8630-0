// Load the 'hello' module
const hello = require('./hello');

// Use the 'hello' module sayHello() method
hello.sayHello();