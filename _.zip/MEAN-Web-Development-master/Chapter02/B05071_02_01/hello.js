// Define a module variable
const message = 'Hello';

// Print message to the console
exports.sayHello = function() {
	console.log(message);
};