// Set the 'production' environment configuration object
module.exports = {
	sessionSecret: 'productionSessionSecret'
};