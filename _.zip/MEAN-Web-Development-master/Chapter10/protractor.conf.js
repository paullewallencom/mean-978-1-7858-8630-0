exports.config = {
	specs: ['public/tests/**/e2e/*.js'],
	useAllAngular2AppRoots: true
}